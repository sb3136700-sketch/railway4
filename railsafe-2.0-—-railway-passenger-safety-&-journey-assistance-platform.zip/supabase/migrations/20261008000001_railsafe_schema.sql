-- RailSafe 2.0 Database Schema for Supabase PostgreSQL
-- Implements Row Level Security (RLS), RBAC, audit logs, and SOS live location tables

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- 1. Profiles Table with RBAC (passenger, operator, responder)
CREATE TABLE IF NOT EXISTS profiles (
  id UUID PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email TEXT UNIQUE NOT NULL,
  name TEXT NOT NULL,
  phone TEXT,
  role TEXT NOT NULL DEFAULT 'passenger' CHECK (role IN ('passenger', 'operator', 'responder')),
  badge_number TEXT,
  department TEXT,
  avatar_url TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

-- Enable RLS
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users can view their own profile"
  ON profiles FOR SELECT
  USING (auth.uid() = id);

CREATE POLICY "Staff can view all profiles"
  ON profiles FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role IN ('operator', 'responder')
    )
  );

CREATE POLICY "Users can update their own profile"
  ON profiles FOR UPDATE
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id AND role = (SELECT role FROM profiles WHERE id = auth.uid()));

-- 2. Emergency Contacts Table
CREATE TABLE IF NOT EXISTS emergency_contacts (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  name TEXT NOT NULL,
  relationship TEXT NOT NULL,
  phone TEXT NOT NULL,
  is_verified BOOLEAN DEFAULT FALSE,
  enabled_for_sos BOOLEAN DEFAULT TRUE,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE emergency_contacts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Passengers can manage their emergency contacts"
  ON emergency_contacts FOR ALL
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- 3. Safety Incidents Table
CREATE TABLE IF NOT EXISTS safety_reports (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reference_id TEXT UNIQUE NOT NULL,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  reporter_name TEXT NOT NULL,
  reporter_phone TEXT,
  category TEXT NOT NULL CHECK (category IN (
    'harassment', 'theft', 'suspicious_activity', 'medical', 
    'overcrowding', 'facility_damage', 'accessibility', 'lost_property', 'other'
  )),
  title TEXT NOT NULL,
  description TEXT NOT NULL,
  train_number TEXT,
  train_name TEXT,
  coach TEXT,
  seat TEXT,
  station TEXT,
  latitude DOUBLE PRECISION,
  longitude DOUBLE PRECISION,
  severity TEXT NOT NULL DEFAULT 'medium' CHECK (severity IN ('low', 'medium', 'high', 'critical')),
  status TEXT NOT NULL DEFAULT 'submitted' CHECK (status IN (
    'submitted', 'under_review', 'assigned', 'in_progress', 'escalated', 'resolved'
  )),
  ai_classification JSONB,
  operator_notes TEXT,
  assigned_responder_id UUID REFERENCES profiles(id),
  assigned_department TEXT,
  is_escalated BOOLEAN DEFAULT FALSE,
  escalation_reason TEXT,
  evidence_urls TEXT[] DEFAULT '{}',
  contact_preference TEXT DEFAULT 'in_app' CHECK (contact_preference IN ('call', 'sms', 'in_app')),
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  updated_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  resolved_at TIMESTAMPTZ
);

ALTER TABLE safety_reports ENABLE ROW LEVEL SECURITY;

-- Passengers can view ONLY their own reports
CREATE POLICY "Passengers view own safety reports"
  ON safety_reports FOR SELECT
  USING (auth.uid() = user_id);

-- Operators and Responders can view and manage all reports
CREATE POLICY "Operators manage all safety reports"
  ON safety_reports FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role IN ('operator', 'responder')
    )
  );

CREATE POLICY "Passengers can insert their own reports"
  ON safety_reports FOR INSERT
  WITH CHECK (auth.uid() = user_id);

-- 4. Incident Audit Logs
CREATE TABLE IF NOT EXISTS incident_audit_logs (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  incident_id UUID NOT NULL REFERENCES safety_reports(id) ON DELETE CASCADE,
  actor_id UUID NOT NULL REFERENCES profiles(id),
  actor_name TEXT NOT NULL,
  actor_role TEXT NOT NULL,
  action TEXT NOT NULL,
  previous_status TEXT,
  new_status TEXT,
  notes TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE incident_audit_logs ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Operators view all audit logs"
  ON incident_audit_logs FOR SELECT
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role IN ('operator', 'responder')
    )
  );

-- 5. SOS Events Table
CREATE TABLE IF NOT EXISTS sos_events (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reference_id TEXT UNIQUE NOT NULL,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  passenger_name TEXT NOT NULL,
  passenger_phone TEXT,
  category TEXT NOT NULL DEFAULT 'urgent_assistance',
  message TEXT,
  status TEXT NOT NULL DEFAULT 'active' CHECK (status IN ('active', 'resolved', 'cancelled')),
  initial_lat DOUBLE PRECISION,
  initial_lng DOUBLE PRECISION,
  current_lat DOUBLE PRECISION,
  current_lng DOUBLE PRECISION,
  location_accuracy DOUBLE PRECISION,
  location_updated_at TIMESTAMPTZ,
  train_number TEXT,
  coach_seat TEXT,
  share_token TEXT UNIQUE NOT NULL,
  share_expires_at TIMESTAMPTZ NOT NULL,
  sms_delivery_status TEXT DEFAULT 'queued',
  sms_recipients_count INT DEFAULT 0,
  provider_message_id TEXT,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW(),
  resolved_at TIMESTAMPTZ
);

ALTER TABLE sos_events ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Passengers view own SOS events"
  ON sos_events FOR SELECT
  USING (auth.uid() = user_id);

CREATE POLICY "Passengers insert own SOS events"
  ON sos_events FOR INSERT
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Passengers update own SOS events"
  ON sos_events FOR UPDATE
  USING (auth.uid() = user_id);

CREATE POLICY "Staff manage all SOS events"
  ON sos_events FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role IN ('operator', 'responder')
    )
  );

-- 6. SOS Location Updates
CREATE TABLE IF NOT EXISTS sos_location_updates (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  sos_event_id UUID NOT NULL REFERENCES sos_events(id) ON DELETE CASCADE,
  latitude DOUBLE PRECISION NOT NULL,
  longitude DOUBLE PRECISION NOT NULL,
  accuracy DOUBLE PRECISION,
  recorded_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE sos_location_updates ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Access location updates for owned SOS or staff"
  ON sos_location_updates FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM sos_events
      WHERE sos_events.id = sos_location_updates.sos_event_id
      AND (sos_events.user_id = auth.uid() OR EXISTS (
        SELECT 1 FROM profiles WHERE id = auth.uid() AND role IN ('operator', 'responder')
      ))
    )
  );

-- 7. Saved Journeys Table
CREATE TABLE IF NOT EXISTS saved_journeys (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  train_number TEXT NOT NULL,
  train_name TEXT NOT NULL,
  from_station TEXT NOT NULL,
  to_station TEXT NOT NULL,
  journey_date DATE NOT NULL,
  pnr TEXT,
  coach TEXT,
  seat TEXT,
  status TEXT DEFAULT 'upcoming',
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE saved_journeys ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users manage own journeys"
  ON saved_journeys FOR ALL
  USING (auth.uid() = user_id);

-- 8. Lost & Found Items Table
CREATE TABLE IF NOT EXISTS lost_items (
  id UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
  reference_id TEXT UNIQUE NOT NULL,
  user_id UUID NOT NULL REFERENCES profiles(id) ON DELETE CASCADE,
  reporter_name TEXT NOT NULL,
  item_type TEXT NOT NULL,
  description TEXT NOT NULL,
  color TEXT,
  train_number TEXT,
  station_or_coach TEXT,
  loss_date DATE NOT NULL,
  status TEXT DEFAULT 'reported' CHECK (status IN ('reported', 'matched', 'claimed', 'closed')),
  match_score INT DEFAULT 0,
  created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
);

ALTER TABLE lost_items ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Users view own lost reports"
  ON lost_items FOR ALL
  USING (auth.uid() = user_id);

CREATE POLICY "Staff manage all lost items"
  ON lost_items FOR ALL
  USING (
    EXISTS (
      SELECT 1 FROM profiles
      WHERE id = auth.uid() AND role IN ('operator', 'responder')
    )
  );
