import React, { createContext, useContext, useState, useEffect } from 'react';
import { UserProfile, UserRole } from '../types';

interface AuthContextType {
  user: UserProfile;
  setUser: (user: UserProfile) => void;
  switchRole: (role: UserRole) => void;
  login: (email: string, role?: UserRole) => void;
  logout: () => void;
  isOperatorOrResponder: boolean;
}

const DEMO_PERSONAS: Record<UserRole, UserProfile> = {
  passenger: {
    id: 'usr-passenger-1',
    email: 'sameer.passenger@railsafe.in',
    name: 'Sameer Khan',
    phone: '+919876543210',
    role: 'passenger',
    createdAt: '2026-01-10T10:00:00Z',
  },
  operator: {
    id: 'usr-operator-1',
    email: 'aditi.nair@irctc.gov.in',
    name: 'Aditi Nair',
    phone: '+919822110099',
    role: 'operator',
    badgeNumber: 'RPF-CTRL-884',
    department: 'Central Railway Safety & Threat Triage Control',
    createdAt: '2025-06-15T09:00:00Z',
  },
  responder: {
    id: 'usr-responder-1',
    email: 'vikram.singh@rpf.gov.in',
    name: 'SI Vikram Singh',
    phone: '+919833445566',
    role: 'responder',
    badgeNumber: 'RPF-BPL-412',
    department: 'Railway Protection Force (Bhopal Division)',
    createdAt: '2025-08-20T11:00:00Z',
  },
};

const AuthContext = createContext<AuthContextType | undefined>(undefined);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<UserProfile>(() => {
    const saved = localStorage.getItem('railsafe_user');
    if (saved) {
      try {
        return JSON.parse(saved);
      } catch (e) {
        // fallback
      }
    }
    return DEMO_PERSONAS.passenger;
  });

  useEffect(() => {
    localStorage.setItem('railsafe_user', JSON.stringify(user));
  }, [user]);

  const switchRole = (role: UserRole) => {
    setUser(DEMO_PERSONAS[role]);
  };

  const login = (email: string, role: UserRole = 'passenger') => {
    const persona = {
      ...DEMO_PERSONAS[role],
      email,
      name: email.split('@')[0].toUpperCase(),
    };
    setUser(persona);
  };

  const logout = () => {
    setUser(DEMO_PERSONAS.passenger);
  };

  const isOperatorOrResponder = user.role === 'operator' || user.role === 'responder';

  return (
    <AuthContext.Provider value={{ user, setUser, switchRole, login, logout, isOperatorOrResponder }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => {
  const context = useContext(AuthContext);
  if (!context) throw new Error('useAuth must be used within an AuthProvider');
  return context;
};
